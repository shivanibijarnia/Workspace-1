package com.capgemini.wallet.controllers;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.wallet.beans.Customer;
import com.capgemini.wallet.services.WalletService;

@Controller
public class CustomerActionController {

	@Autowired(required=true)
	private WalletService walletService;
	
	@RequestMapping(value="/registerCustomer")
	public ModelAndView register(@ModelAttribute("customer")Customer customer,BindingResult res)
	{
		customer=walletService.createAccount(customer);
		ModelAndView modelAndView=new ModelAndView("registrationSuccess","customer",customer);
		return modelAndView;
		
	}
	
	@RequestMapping(value="/depositCustomer")
	public ModelAndView deposit(@RequestParam("mobileNo")String mobileNo,@RequestParam("wallet.balance")BigDecimal amount)
	{
		Customer customer=walletService.depositAmount(mobileNo, amount);
		ModelAndView modelAndView=new ModelAndView("viewBalanceSuccess","customer",customer);
		return modelAndView;
	}
	@RequestMapping(value="/withdrawCustomer")
	public ModelAndView withdraw(@RequestParam("mobileNo")String mobileNo,@RequestParam("wallet.balance")BigDecimal amount)
	{
		Customer customer=walletService.depositAmount(mobileNo, amount);
		ModelAndView modelAndView=new ModelAndView("viewBalanceSuccess","customer",customer);
		return modelAndView;
	}
	@RequestMapping(value="/viewBalance")
	public ModelAndView showBalance(@ModelAttribute("customer")Customer customer,BindingResult res)
	{
		customer=walletService.showBalance(customer.getMobileNo());
		ModelAndView modelAndView=new ModelAndView("viewBalanceSuccess","customer",customer);
		return modelAndView;
	}
	@RequestMapping(value="/fundTransfer")
	public ModelAndView transferFund(@RequestParam("mobileNo1")String mobileNo1,@RequestParam("mobileNo2")String mobileNo2,@RequestParam("wallet.balance")BigDecimal amount)
	{
		Customer customer=walletService.fundTransfer(mobileNo1,mobileNo2,amount);
		ModelAndView modelAndView=new ModelAndView("viewBalanceSuccess","customer",customer);
		return modelAndView;
	}
}
