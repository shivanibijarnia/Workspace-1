package com.capgemini.wallet.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.capgemini.wallet.beans.Customer;

@Controller
public class URIController {

	@RequestMapping(value="/")
	public String getIndexPage()
	{
		return "indexPage";
	}
	@RequestMapping(value="/login")
	public String getLoginPage()
	{
		return "login";
	}
	@RequestMapping(value="/register")
	public String getRegistration()
	{
		return "register";
	}
	@RequestMapping(value="/deposit")
	public String getDeposit()
	{
		return "deposit";
	}
	@RequestMapping(value="/withdraw")
	public String getWithdraw()
	{
		return "withdraw";
	}
	@RequestMapping(value="/viewBal")
	public String getBal()
	{
		return "viewBalance";
	}
	@RequestMapping(value="/transfer")
	public String getFundtransfer()
	{
		return "fundTransfer";
	}

	@ModelAttribute("customer")
	public Customer getCustomer() {
		return new Customer();
	}
	
}
