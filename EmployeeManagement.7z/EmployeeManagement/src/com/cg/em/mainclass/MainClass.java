package com.cg.em.mainclass;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.em.beans.Employee;
import com.cg.em.services.EmployeeManagementService;

public class MainClass {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("projectBeans.xml");
		Employee employee = (Employee) context.getBean("employee");
		System.out.println(employee);
		
	}
}
