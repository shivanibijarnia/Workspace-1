package com.cg.em.services;

public interface EmployeeManagementService {

}
