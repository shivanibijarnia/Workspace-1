package com.capgemini.wallet.controllers;

import java.math.BigDecimal;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.wallet.beans.Customer;
import com.capgemini.wallet.exception.InvalidInputException;
import com.capgemini.wallet.services.WalletService;

@Controller
public class CustomerActionController {

	@Autowired(required=true)
	private WalletService walletService;
	
	@RequestMapping(value="/registerCustomer")
	public ModelAndView register(@Valid @ModelAttribute("customer")Customer customer,BindingResult res)
	{
		if (res.hasErrors())return new ModelAndView("register");
		customer=walletService.createAccount(customer);
		ModelAndView modelAndView=new ModelAndView("registrationSuccess","customer",customer);
		return modelAndView;
		
	}
	
	@RequestMapping(value="/depositCustomer")
	public ModelAndView deposit(@RequestParam("mobileNo")String mobileNo,@RequestParam("wallet.balance")BigDecimal amount)
	{
		Customer customer = null;
		try {
			customer = walletService.depositAmount(mobileNo, amount);
		} catch (InvalidInputException e) {
			// TODO Auto-generated catch block
			e.getMessage();
			String error="You entered wrong mobile number.Please try again!!";
			return new ModelAndView("login","error",error);
		}
		ModelAndView modelAndView=new ModelAndView("viewBalanceSuccess","customer",customer);
		return modelAndView;
	}
	@RequestMapping(value="/withdrawCustomer")
	public ModelAndView withdraw(@RequestParam("mobileNo")String mobileNo,@RequestParam("wallet.balance")BigDecimal amount)
	{
		Customer customer;
		try {
			customer = walletService.withdrawAmount(mobileNo, amount);
		} catch (InvalidInputException e) {
			// TODO Auto-generated catch block
			e.getMessage();
			String error="You entered wrong mobile number.Please try again!!";
			return new ModelAndView("login","error",error);
		}
		ModelAndView modelAndView=new ModelAndView("viewBalanceSuccess","customer",customer);
		return modelAndView;
	}
	@RequestMapping(value="/viewBalance")
	public ModelAndView showBalance(@Valid @ModelAttribute("customer")Customer customer,BindingResult res)
	{
		
		try {
			customer=walletService.showBalance(customer.getMobileNo());
		} catch (InvalidInputException e) {
			// TODO Auto-generated catch block
			e.getMessage();
			String error="You entered wrong mobile number.Please try again!!";
			return new ModelAndView("login","error",error);
		}
		ModelAndView modelAndView=new ModelAndView("viewBalanceSuccess","customer",customer);
		return modelAndView;
	}
	@RequestMapping(value="/fundTransfer")
	public ModelAndView transferFund(@RequestParam("mobileNo1")String mobileNo1,@RequestParam("mobileNo2")String mobileNo2,@RequestParam("wallet.balance")BigDecimal amount)
	{
		Customer customer = null;
		try {
			customer = walletService.fundTransfer(mobileNo1,mobileNo2,amount);
		} catch (InvalidInputException e) {
			// TODO Auto-generated catch block
			e.getMessage();
			String error="You entered wrong mobile number.Please try again!!";
			return new ModelAndView("login","error",error);
			
		}
		ModelAndView modelAndView=new ModelAndView("viewBalanceSuccess","customer",customer);
		return modelAndView;
	}
}
