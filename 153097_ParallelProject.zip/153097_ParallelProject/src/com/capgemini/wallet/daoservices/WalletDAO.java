package com.capgemini.wallet.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.wallet.beans.Customer;

public interface WalletDAO extends JpaRepository<Customer, String>{

}
