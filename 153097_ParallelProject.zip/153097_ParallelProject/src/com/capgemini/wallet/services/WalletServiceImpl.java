package com.capgemini.wallet.services;

import java.math.BigDecimal;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.capgemini.wallet.beans.Customer;
import com.capgemini.wallet.beans.Wallet;
import com.capgemini.wallet.daoservices.WalletDAO;
import com.capgemini.wallet.exception.InvalidInputException;

@Component(value="walletService")
public class WalletServiceImpl implements WalletService {

	@Autowired(required=true)
	private WalletDAO walletDao;
	
	@Transactional
	@Override
	public Customer createAccount(Customer customer) {
		return walletDao.save(customer);
	}

	@Transactional
	@Override
	public Customer showBalance(String mobileno) throws InvalidInputException{
		// TODO Auto-generated method stub
		Customer customer=walletDao.findOne(mobileno);
		if(customer==null)
			throw new InvalidInputException("Invalid Number");

		return customer;
	}

	@Transactional
	@Override
	public Customer fundTransfer(String sourceMobileNo, String targetMobileNo, BigDecimal amount) throws InvalidInputException {
		Customer customer=withdrawAmount(sourceMobileNo,amount);
		Customer customer1=depositAmount(targetMobileNo, amount);

		
		return customer;
	}

	@Transactional
	@Override
	public Customer depositAmount(String mobileNo, BigDecimal amount)throws InvalidInputException {
		Customer customer=walletDao.findOne(mobileNo);
		if(customer==null)
			throw new InvalidInputException("Invalid phone number");
		Wallet wallet=customer.getWallet();
		BigDecimal bal=wallet.getBalance();
		wallet.setBalance(bal.add(amount));
		customer.setWallet(wallet);
		return walletDao.save(customer);
		
	}

	@Transactional
	@Override
	public Customer withdrawAmount(String mobileNo, BigDecimal amount)throws InvalidInputException{
		Customer customer=walletDao.findOne(mobileNo);
		if(customer==null)
			throw new InvalidInputException("Invalid phone number");
		Wallet wallet=customer.getWallet();
		BigDecimal bal=wallet.getBalance();
		if(amount.compareTo(bal)>=0)
		{
			
		}
		else {	
		wallet.setBalance(bal.subtract(amount));
		customer.setWallet(wallet);
		
		}
		return walletDao.save(customer);
	}

}
